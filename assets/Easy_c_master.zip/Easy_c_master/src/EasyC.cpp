﻿#include"../include/EasyC.h"

func Main() {

}

start() {
	text Text;
	text command;

	input(Text);
	print(Text);

	done;
}